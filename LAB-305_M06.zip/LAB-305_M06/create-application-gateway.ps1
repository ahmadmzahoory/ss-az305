<#	
	Version:        1.0
	Author:         Ahmad Majeed Zahoory
	Creation Date:  20th May, 2022
	Purpose/Change: Create Application Gateway

#>

############################################## Variables ##################################################################
# Variables for common values
$resourceGroup = "az-305-06-rg"
$location = "westeurope"
$vnet   = Get-AzVirtualNetwork -ResourceGroupName $resourceGroup -Name n-tier_vnet
$subnet = Get-AzVirtualNetworkSubnetConfig -VirtualNetwork $vnet -Name lbsubnet
Set-Item Env:\SuppressAzurePowerShellBreakingChangeWarnings "true"

#######################################  Application Gateway Configuration ##############################################

# Create Public IP address for Application Gateway
$pip = New-AzPublicIpAddress -ResourceGroupName $resourceGroup -Location $location -Name invapplb-Pub-IP -AllocationMethod Static -Sku Standard -Zone 1,2

# Create Application Gateway IP configurations and frontend port
$gipconfig = New-AzApplicationGatewayIPConfiguration -Name invapplb-IPConfig -Subnet $subnet
$fipconfig = New-AzApplicationGatewayFrontendIPConfig -Name invapplb-FrontendIPConfig -PublicIPAddress $pip
$frontendport = New-AzApplicationGatewayFrontendPort -Name invapplb-HTTP -Port 80

# Create Application Gateway backend pool
$backendPool = New-AzApplicationGatewayBackendAddressPool -Name invapplb-BackendPool
$poolSettings = New-AzApplicationGatewayBackendHttpSetting -Name invapplb-PoolSettings -Port 80 -Protocol Http -CookieBasedAffinity disabled

# Create Application Gateway listener and add a rule
$defaultlistener = New-AzApplicationGatewayHttpListener `
  -Name invapplb-Listener `
  -Protocol Http `
  -FrontendIPConfiguration $fipconfig `
  -FrontendPort $frontendport
$frontendRule = New-AzApplicationGatewayRequestRoutingRule `
  -Name invapplb-rule `
  -RuleType Basic `
  -Priority 1 `
  -HttpListener $defaultlistener `
  -BackendAddressPool $backendPool `
  -BackendHttpSettings $poolSettings
  
# Create Application Gateway sku and autoscaling configuration 
$sku = New-AzApplicationGatewaySku -Name Standard_v2 -Tier Standard_v2 
$autoscale = New-AzApplicationGatewayAutoscaleConfiguration -MinCapacity 2 -MaxCapacity 4

# Create Application Gateway health probe 
$probe = New-AzApplicationGatewayProbeConfig -Name "invapplb-healthProbe" -PickHostNameFromBackendHttpSettings -Protocol Http -Path "/" -Interval 30 -Timeout 30 -UnhealthyThreshold 3

#################################### Application Gateway Configuration #####################################################

# Create Application Gateway 
New-AzApplicationGateway `
  -Name inventoryapp-lb `
  -Zone 1,2 `
  -ResourceGroupName $resourceGroup `
  -Location $location `
  -BackendAddressPools $backendPool `
  -BackendHttpSettingsCollection $poolSettings `
  -FrontendIpConfigurations $fipconfig `
  -GatewayIpConfigurations $gipconfig `
  -FrontendPorts $frontendport `
  -HttpListeners $defaultlistener `
  -RequestRoutingRules $frontendRule `
  -Sku $sku `
  -AutoscaleConfiguration $autoscale `
  -Probes $probe
  
  
# End