<#	
	Version:        1.0
	Author:         Ahmad Majeed Zahoory
	Creation Date:  1st June, 2022
	Purpose/Change: Build Migration Environment

#>

############################################## Variables ############################################################

# Variables for common values
$resourceGroup1 = "az-305-08-rg1"
$location1 = "eastus"
$resourceGroup2 = "az-305-08-rg2"
$location2 = "westeurope"
Set-Item Env:\SuppressAzurePowerShellBreakingChangeWarnings "true"

####################################### Migration Virtual Network ######################################################

# Create a resource group
New-AzresourceGroup -Name $resourceGroup1 -location $location1
New-AzresourceGroup -Name $resourceGroup2 -location $location2

# Create a virtual network with subnet
$subnet1 = New-AzVirtualNetworkSubnetConfig -Name websubnet -AddressPrefix 192.168.0.0/24
$subnet2 = New-AzVirtualNetworkSubnetConfig -Name dBsubnet -AddressPrefix 192.168.1.0/24
$vnet = New-AzVirtualNetwork -resourceGroupName $resourceGroup2 -Name migration-vnet -AddressPrefix 192.168.0.0/23 `
  -location $location2 -Subnet $subnet1, $subnet2

############################################ Primary Caching Storage ########################################################

$SkuName = "Standard_LRS"
$Prefix = "lab305stgmig"

#Create Storageaccount
function New-RandomName {
( -join ((48..57) + (65..90) + (97..122) | Get-Random -Count 10 | % {[char]$_}))
}
do {
        $SARandomName = New-RandomName
        $SAName = ($Prefix + $SARandomName).ToLower()
        $Availability = Get-AzStorageAccountNameAvailability -Name $SAName
    }
while ($Availability.NameAvailable -eq $false)
    
New-AzStorageAccount -resourceGroupName $resourceGroup2 -Name $SAName -location $location2 -SkuName $SkuName
 

################################# Public IP Address for Hyoer V Server #################################################

# Create a public IP address and specify a DNS name
New-AzPublicIpAddress -ResourceGroupName $resourceGroup1 -Location $location1 `
  -Name hyperv-pip  -AllocationMethod Dynamic -IdleTimeoutInMinutes 4


################################# Public IP Address for Web Migration Server #################################################

# Create a public IP address and specify a DNS name
New-AzPublicIpAddress -ResourceGroupName $resourceGroup2 -Location $location2 `
  -Name imgwebsrv-pip -AllocationMethod Dynamic -IdleTimeoutInMinutes 4
  
####End